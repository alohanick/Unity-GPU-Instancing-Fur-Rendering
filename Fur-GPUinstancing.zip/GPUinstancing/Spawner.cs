﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class ObjData
{
    public Vector3 pos;
    public Vector3 scale;
    public Quaternion rot;
    public Color clr;
    public float layer;
    public Matrix4x4 matrix
    {
        get
        {
            return Matrix4x4.TRS(pos, rot, scale);
        }
    }
}

public class Spawner : MonoBehaviour
{
    public int count;
    public Vector3 maxPos;
    public Mesh mesh;
    public Material mtrlBatched, mtrlNoBatch;
    public GameObject Target;
    [Range(0,10)]
    public float Hard=2.0f;

    private List<ObjData> batch = new List<ObjData>();
    void Start()
    {
        for (int i = 0; i< count; i++){
            var obj=new ObjData(){
                pos=Target.transform.position,
                rot=Target.transform.rotation,
                scale=Vector3.one*(1+(float)i/800),
                clr = Random.ColorHSV(),
                layer=i * 1.0f/ count,
            };

            batch.Add(obj);
        }
    }

    // Update is called once per frame
    List<ObjData> curBatch = new List<ObjData>();
    void Update()
    {
        //DrawMesh();//不合批的渲染效果
        //DrawInstancedSingle();//合批但是一个物体一个批次渲染
        DrawInstanceBatched();//合批统一渲染
    }

    void DrawMesh()//不合批的渲染方法
    {
        for (int i = 0; i < batch.Count; i++)
        {
            var obj = batch[i];
            Graphics.DrawMesh(mesh, obj.matrix, mtrlNoBatch, 0);
        }
    }

    void DrawInstancedSingle()//合批但是一个物体一个批次渲染
    {
        for (int i = 0; i < batch.Count; i++)
        {
            var obj = batch[i];
            float lerpSpeed = (count-i)*Hard;
            obj.pos=Vector3.Lerp(obj.pos, Target.transform.position, lerpSpeed * Time.deltaTime);
            obj.rot=Quaternion.Lerp(obj.rot, Target.transform.rotation, lerpSpeed * Time.deltaTime);

            MaterialPropertyBlock props = new MaterialPropertyBlock();

            props.SetFloat("_LayerOffset", obj.layer);

            Graphics.DrawMeshInstanced(mesh, 0, mtrlBatched, new[] { obj.matrix }.ToList(), props);
        }
    }

    void DrawInstanceBatched()//合批统一渲染
    {
        for (int i = 0; i < batch.Count; i++)
        {
            var obj = batch[i];

            float lerpSpeed = (count-i)*3*Hard;
            obj.pos=Vector3.Lerp(obj.pos, Target.transform.position, lerpSpeed * Time.deltaTime);
            obj.rot=Quaternion.Lerp(obj.rot, Target.transform.rotation, lerpSpeed * Time.deltaTime);

            curBatch.Add(obj);
            if (curBatch.Count == 1023 || i == batch.Count - 1)
            {
                MaterialPropertyBlock props = new MaterialPropertyBlock();

                props.SetFloatArray("_LayerOffset", curBatch.Select(x => x.layer).ToList());

                Graphics.DrawMeshInstanced(mesh, 0, mtrlBatched, curBatch.Select(x => x.matrix).ToList(), props);

                curBatch.Clear();
            }
        }
    }
}
